from django.shortcuts import render

from store.models.orderdetails import OrderDetails


def OrderDe(request,id):
    # oid = request.GET.get('oid')
    orderdetails = OrderDetails.objects.filter(order=id)
    print('order details', orderdetails)
    for o in orderdetails:
        print(o.qty," ", o.price, " ", o.order)
        print(o.product.name, type(o.product.name))
    return render(request, 'orderdetails.html', {'orderdetails':orderdetails})
    # return render(request, 'orderdetails.html')
