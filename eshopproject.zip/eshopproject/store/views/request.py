from django.shortcuts import render, redirect

#
# def ProccessRequest(request):
#     return render(request, '/proccessrequest.html')
from django.views import View


class ProccessRequest(View):
    def get(self, request):
        return render(request, 'proccessrequest.html')
        # redirect('proccessrequest.html')
