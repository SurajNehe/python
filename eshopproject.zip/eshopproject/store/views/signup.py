from django.shortcuts import render, redirect
from django.contrib.auth.hashers import make_password
from store.models.customer1 import Account
from django.views import View


class Signup(View):
    def get(self, request):
        return render(request, 'signup.html')

    def post(self, request):
        postData = request.POST
        # first_name = postData.get('firstname')
        username = postData.get('username')
        phone = postData.get('phone')
        email = postData.get('email')
        password = postData.get('password')
        # validation
        value = {
            'username': username,
            # 'last_name': last_name,
            'phone': phone,
            'email': email,
            'password': password
        }
        error_message = None

        customer = Account(username=username,
                           email=email,
                           phone= phone,
                           password=password)
        error_message = self.validateCustomer(customer)

        if not error_message:
            print(username, email, phone, password)
            customer.password = make_password(customer.password)
            customer.register()
            return redirect('homepage')
        else:
            data = {
                'error': error_message,
                'values': value
            }
            return render(request, 'signup.html', data)

    def validateCustomer(self, customer):
        error_message = None;
        if (not customer.username):
            error_message = "First Name Required !!"
        elif len(customer.username) < 0:
            error_message = 'First Name must be 1 char long or more'
        # elif not customer.last_name:
        #     error_message = 'Last Name Required'
        # elif len(customer.last_name) < 0:
        #     error_message = 'Last Name must be 1 char long or more'
        elif not customer.phone:
            error_message = 'Phone Number required'
        elif len(customer.phone) < 10:
            error_message = 'Phone Number must be 10 char Long'
        elif len(customer.password) < 6:
            error_message = 'Password must be 6 char long'
        elif len(customer.email) < 5:
            error_message = 'Email must be 5 char long'
        elif customer.isExists():
            error_message = 'Email Address Already Registered..'
        # saving

        return error_message
