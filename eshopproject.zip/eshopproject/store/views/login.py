from django.core.checks import messages
from django.shortcuts import render, redirect, HttpResponseRedirect

from django.contrib.auth.hashers import check_password

# from store.decorators import unauthenticated_user
from store.models.customer1 import Account
from django.views import View


#
# @unauthenticated_user
# def registerPage (request):
#     form = CreateUserForm()
#     if request.method == 'POST':
#         form= CreateUserForm(request. POST)
#         if form.is_valid():
#             form.save()
#             user = form.cleaned_data.get('username')
#             messages.success (request, 'Account was create')
#             return redirect('login')
#             context = {'form': form}
#             return trender (request, 'accounts/register.html', context)
#


class Login(View):
    return_url = None

    # @unauthenticated_user
    def get(self, request):
        Login.return_url = request.GET.get('return_url')
        return render(request, 'login.html')

    def post(self, request):
        email = request.POST.get('email')
        password = request.POST.get('password')
        print(email)
        print(password)
        # customer = Account.get_customer_by_email(email)
        customer = Account.object.get(email=email)
        print('customer = ', customer)
        print(type(customer))
        # is_admin = Account.is_admin()
        error_message = None
        

        # Code is refactored..................17/02/2022
        if customer:
            if customer.is_admin:
                # return render(request, 'ProccessRequest/')
                return redirect('processrequest')
            # else:
            flag = check_password(password, customer.password)
            if flag:
                request.session['customer'] = customer.id
                request.session['customer_name'] = customer.username
                if Login.return_url:

                    return HttpResponseRedirect(Login.return_url)
                else:
                    Login.return_url = None
                    return redirect('homepage')
            else:
                error_message = 'Email or Password invalid !!'
        else:
            error_message = 'Email or Password invalid !!'

        print(email, password)
        return render(request, 'login.html', {'error': error_message})



        # if customer:
        #     flag = check_password(password, customer.password)
        #     if flag:
        #         request.session['customer'] = customer.id
        #         print(customer.username)
        #
        #         if Login.return_url:
        #             return HttpResponseRedirect(Login.return_url)
        #         else:
        #             # Login.return_url = None
        #             if customer.is_admin:
        #                 redirect('proccessrequest/')
        #             else:
        #                 return redirect('homepage')
        #     else:
        #         error_message = 'Email or Password invalid !!'
        # else:
        #     error_message = 'Email or Password invalid !!'
        #
        # print(email, password)
        # return render(request, 'login.html', {'error': error_message})



        # if customer:
        #     flag = check_password(password, customer.password)
        #     if flag:
        #         request.session['customer'] = customer.id
        #         request.session['customer_name'] = customer.username
        #
        #         if Login.return_url:
        #
        #             return HttpResponseRedirect(Login.return_url)
        #         else:
        #             Login.return_url = None
        #             if customer.is_admin:
        #                 # return render(request, 'ProccessRequest/')
        #                 redirect('/ProccessRequest')
        #             else:
        #                 return redirect('homepage')
        #     else:
        #         error_message = 'Email or Password invalid !!'
        # else:
        #     error_message = 'Email or Password invalid !!'
        #
        # print(email, password)
        # return render(request, 'login.html', {'error': error_message})









def logout(request):
    request.session.clear()
    return redirect('login')
