from django.shortcuts import render, redirect

from django.contrib.auth.hashers import check_password

from store.models import Category, OrderDetails
from store.models.customer1 import Account
from django.views import View

from store.models.product import Product
from store.models.orders import Order


class CheckOut(View):
    def post(self, request):
        address = request.POST.get('address')
        phone = request.POST.get('phone')
        customer = request.session.get('customer')
        cart = request.session.get('cart')
        products = Product.get_products_by_id(list(cart.keys()))
        print(address, phone, customer, cart, products)
        total_sum=0
        for product in products:

            total_sum=total_sum+product.price
        print('total price =', total_sum)
        total_quantity=0
        for k in cart.keys():
            total_quantity=total_quantity+cart[k]
        print('total quantity = ',total_quantity)

        # for product in products:
        #     print(cart.get(str(product.id)))
        order = Order(customer=Account(id=customer),
                      price=total_sum,
                      address=address,
                      phone=phone,
                      quantity=total_quantity)
        order.save()
        cat1 = Category(name='mobile')
        for product in products:
            # p1=Product(name=product.name,
            #            price=product.price,
            #            category=product.category,
            #            desciption=product.description,
            #            image=product.image)
            # p1.save()
            product_ids=cart.keys()
            qty=0
            for k in product_ids:
                print('Product key : ' ,k , type(k))
                if((int)(k) == product.id):
                    qty= cart[k]
                    break

            #if(product.id in product_ids):
            #qty=cart[product.id]

            od1=OrderDetails(qty=qty,
                             price=product.price,
                             order=order,
                             product=product)
            od1.save()



            # print(cart.get(str(product.id)), ' ', product.price)
        request.session['cart'] = {}

        return redirect('cart')