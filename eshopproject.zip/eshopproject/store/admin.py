from django.contrib import admin
from .models.product import Product
from .models.category import Category
from .models.customer1 import Account
from .models.orders import Order
from .models.orderdetails import OrderDetails
from django.contrib.auth.admin import UserAdmin


class AdminProduct(admin.ModelAdmin):
    list_display = ['name', 'price', 'category']


class AdminCategory(admin.ModelAdmin):
    list_display = ['name']


class AccountAdmin(UserAdmin):
    list_display = ('email', 'username', 'date_joined', 'last_login', 'is_admin', 'is_staff')
    search_fields = ('email', 'username')
    readonly_fields = ('id', 'date_joined', 'last_login')
    filter_horizontal = ()
    list_filter = ()
    fieldsets = ()
    # Register your models here.


admin.site.register(Product, AdminProduct)
admin.site.register(Category, AdminCategory)
admin.site.register(Account, AccountAdmin)
admin.site.register(Order)
admin.site.register(OrderDetails)
