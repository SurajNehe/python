from django.contrib.auth.models import AbstractBaseUser, BaseUserManager
from django.db import models
from django.core.validators import MinLengthValidator

from store.models.myaccountmanager import MyAccountManager


class Account(AbstractBaseUser):
    email = models.EmailField(verbose_name="email", max_length=60, unique=True)
    username= models.CharField(max_length=30, unique=True)
    phone = models.CharField(max_length=15, default=None)
    password = models.CharField(max_length=500)
    date_joined = models.DateTimeField (verbose_name="date joined", auto_now_add=True)
    last_login=models.DateTimeField(verbose_name="last login", auto_now=True)
    is_admin = models.BooleanField(default=False)
    is_active= models.BooleanField (default=True)
    is_staff=models.BooleanField (default=False)
    is_superuser= models.BooleanField(default=False)
    # profile_image= models. ImageField (max_length=255, upload_to-get_profile_image_filepath, models. BooleanField(default=True)
    hide_email=models.BooleanField(default=True)
    object=MyAccountManager()

    USERNAME_FIELD= 'email'
    REQUIRED_FIELDS = ['username', 'email']

    def __str__(self):
        return self.username

    def has_perm(self,perm,obj=None):
        return self.is_admin

    def has_module_perm(self,app_label):
        return True


    def register(self):
        self.save()

    @staticmethod
    def get_customer_by_email(email):
        try:
            print("In Try", object)
            print(Account.object.get(email=email))
            return Account.object.filter(email=email)
        except:
            return False

    def isExists(self):
        if Account.object.filter(email=self.email):
            return True

        return False

