from django.db import models
from .product import Product
from .orders import Order


class OrderDetails(models.Model):
    qty = models.IntegerField(default=1)
    price = models.IntegerField()
    order = models.ForeignKey(Order,
                              on_delete=models.CASCADE)
    product = models.ForeignKey(Product,
                                on_delete=models.CASCADE)

    class Meta:
        db_table = 'OrderDetails'
